# miniRepo_Asn1
A mini repository for assignment 1 in DEM 2019-2020

some changes
