# miniRepo_Asn4
Assignment 4 of DEM
