% Author: Tomohito Okabe
% Date: February 2013
% Corresponds to: U(c) in Listing 5.1

function [ utility ] = flowUtility( c )

global beta
utility = c.^beta;

end

