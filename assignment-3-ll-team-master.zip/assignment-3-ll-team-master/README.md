# miniRepo_Asn3
Assignment 3 for Dynamic Economic Model

main.ipynb is the document of Colonell problem that you've seen during lab. 
asn_3-2020.ipynb is the assignment question.
