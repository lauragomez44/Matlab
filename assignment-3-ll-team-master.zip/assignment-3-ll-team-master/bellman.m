% Author: Tomohito Okabe
% Date: February 2013
function [ psiv, alpha ] = bellman(v)

global rho M S Z

% shock distribution
p = phi(Z);

% Array of feasible actions: one column for each state element
G = Gamma(S);  

C = ones(1,1+M)'*S - G; % Generate a grid for consumption
C = max(0,C);           % Replace negative values with zero
u = flowUtility(C);     % Flow utility

v_new = nan(size(v)); % initialize

% Compute expected value of next period
for i= 1:size(G,1)      
    for j = 1:length(S)     
        a = G(i,j); 
        v_new(i,j) = sum(v(a+1:a+length(Z)).*p);
    end 
end

y = u + rho*v_new;
% In each state, maximize y by choosing alpha. Store both the maximum and
% the maximizer
for i=1:length(S)
    [psiv(i), alpha(i)] = max(y(:,i));
end
alpha = alpha - 1; % change from index to action
end