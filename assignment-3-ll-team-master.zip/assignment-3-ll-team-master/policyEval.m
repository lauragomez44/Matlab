% Author: Tomohito Okabe
% Date: February 2013
% Corresponds to: Listing 5.2

function v_alpha = policyEval(alpha)
    global rho S

    % Set up \Pi^{\alpha} :
    len = length(S);
    Pi_alpha = zeros(len,len);
    y = S;
    for x = S
        Pi_alpha(x+1,:) = phi(y - alpha(x+1));
    end
    
    % Set up the function r_alpha as an array :
    % Initialize r_alpha into a column vector
    % r_alpha is the flow utility from consumption, as a function of states
    r_alpha = zeros(len,1);
    for x = S
        c = max(0,x-alpha(x+1));
        r_alpha(x+1) = flowUtility(c);
    end
    
    % truncated geometric sum
    v_alpha = zeros(len,1);
    discount = 1;
    for i=1:500
        v_alpha = v_alpha + discount * r_alpha;
        r_alpha = Pi_alpha * r_alpha;
        discount = discount * rho;
    end
v_alpha = v_alpha';

end