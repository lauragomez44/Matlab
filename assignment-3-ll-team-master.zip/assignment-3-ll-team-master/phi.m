% Author: Tomohito Okabe
% Date: February 2013
% Corresponds to: phi(z) in Listing 5.1

function [ dist ] = phi(z)

global B

% Generate z replacing zero elements with one, 
% and more-than-B elements with zero for the subsequent line. 
for i = 1:length(z)
    if z(i) == 0
        z(i) =1;
    elseif z(i)> B
        z(i)=0;
    end
end

% Probability mass function, uniform distribution.
% length z(z>0)) counts the number of positive intergers in Z. 
dist = unidpdf(z,length(z(z>0))); 

end
